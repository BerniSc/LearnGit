#include <iostream>

#include "ros/ros.h" 
#include "geometry_msgs/Pose2D.h"

using namespace std;

geometry_msgs::Pose2D waypoint;

float _waypointX, _waypointY;

static const float maxSizeField = 11; 

// Get Userinput for Goal Point
void set_waypoint() {
    cout << "Wohin soll die Olga?" << endl; 
    cout << "x: ";
    cin >> _waypointX;
    while(_waypointX > maxSizeField) _waypointX -= maxSizeField;
    waypoint.x = _waypointX;
    cout << "y: ";
    cin >> _waypointY;
    while(_waypointY > maxSizeField) _waypointY -= maxSizeField;
    waypoint.y = _waypointY;
    cout << endl;  
}

int main(int argc, char **argv) { 
    // Initiate ROS
    ros::init(argc, argv, "waypoint_publisher");

    // Create the main access point to communicate with ROS
    ros::NodeHandle node;

    // Publish waypoint to a topic.
    // Hold no messages in the queue. Automatically throw away 
    // any messages that are not able to be processed quickly enough.
    ros::Publisher waypointPub = node.advertise<geometry_msgs::Pose2D>("waypoint", 0);

    // Keep running the while loop below as long as the ROS Master is active. 
    while(ros::ok()) {
        // Ask the user where he wants the robot to go
        set_waypoint();

        // Publish the waypoint to the ROS topic
        waypointPub.publish(waypoint);
    }

return 0;
}